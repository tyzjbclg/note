package edu.njit.ListNode;

public class NodeReserve {
    public static<T> void Reserve(SinglyList<T> list){
        Node<T>front=null;
        Node<T> nextNode;
        Node<T> now = list.head.next;
        while(now!=null){
            nextNode=now.next;
            now.next=front;
            front=now;
            now=nextNode;
        }
        list.head.next=front;
    }

    public static void main(String[] args) {
        Integer [] arr=new Integer[]{1, 2, 3, 4, 5};
        SinglyList <Integer> node=new SinglyList(arr);
        System.out.println("逆转前的链表为:"+node.toString());
        Reserve(node);
        System.out.println("逆转前的链表为:"+node.toString());
    }
}
