package edu.njit.ListNode;

public class SinglyList<T> extends Object{
    public Node<T> head;
    public SinglyList(){
        this.head=new Node<T>();
    }
    public SinglyList(T [] values){
        this();
        Node<T>rear=this.head;
        for(int i=0;i<values.length;i++){
            if(values[i]!=null){
                rear.next=new Node<T>(values[i],null);
                rear=rear.next;
            }
        }
    }
    public SinglyList(SinglyList<T> list){
        this();
        Node<T>rear=this.head;
        for(Node<T> p=list.head.next;p!=null;p=p.next){
            rear.next=new Node<T>(p.data,p.next);
            rear=rear.next;
        }
    }
    public boolean isEmpty(){
        return this.head.next==null;
    }
    public T get (int i){
        Node<T> p=this.head.next;
        for(int j=0;j<i&&p!=null;j++)
            p=p.next;
        return (i>=0&&p!=null)? p.data:null;
    }
    public void set(int i, T x){
        Node<T> p=this.head.next;
        for(int j=0;j<i&&p!=null;j++)
            p=p.next;
        p.data=x;
    }
    public int size(){
        int length=0;
        for(Node<T>p=this.head.next;p!=null;p=p.next){
            length=length+1;
        }
        return length;
    }
    public String toString(){
        String str=this.getClass().getName()+"(";  //返回类名
        for(Node<T> p=this.head.next;p!=null;p=p.next)
            str+=p.data.toString()+(p.next!=null?",":"");
        return str+")";
    }
    public Node<T> insert(int i,T x){
        if(x==null)
            return null;
        Node<T> front=this.head;
        for(int j=0;front.next!=null&&j<i;j++)
            front=front.next;
        front.next=new Node<T>(x,front.next);
        return front.next;
    }
    public SinglyList<T>remove(int i,int n){
        Node<T> front=this.head;
        Node<T>rear=this.head;
        for(int j=1;j<i;j++){
            front=front.next;
        }
        for(int x=0;x<n;x++){
            rear=rear.next;
        }
        SinglyList<T>d=new SinglyList<>();
        Node<T>dRear=d.head;
        for(Node p=front.next;p!=rear;p=p.next){
            dRear.next=p;
            dRear=dRear.next;
        }
        dRear.next=null;
        front.next=rear;
        return d;
    }
    public Node<T> insert(T x){
        return insert(Integer.MAX_VALUE,x);
    }
    public T remove(int i){
        Node<T> front=this.head;
        for(int j =0;front.next!=null&&j<i;j++)
            front=front.next;
        if(i>=0&&front.next!=null){
            T x=front.next.data;
            front.next=front.next.next;
            return x;
        }
        return null;
    }
    public void clear(){
        this.head.next=null;  //Java自动收回所有节点占用的空间
    }
    public Node<T> searchKey(T key){
        int i=0;
        Node<T>value=null;
        for(Node<T> p=this.head;p.next!=null;p=p.next){
            if (p.data==key){
                i=1;
                value=p;
                break;
            }
        }
        return i==1? value :null;
    }
    public T removeKey(T key){
        int i=0;
        Node<T>front=this.head;
        for(Node<T>p=this.head;p.next!=null;p=p.next){
            if(p.data==key){
                i=1;
                break;
            }
            else if(p!=this.head)
                front=front.next;
        }
        if(i==0){
            return null;
        }
        else{
            front.next=front.next.next;
            return key;
        }
    }
    public static void main(String[] args) {
        Integer [] arr=new Integer[]{1, 2, 3, 4, 5};
        Integer [] arr1=new Integer[]{1, 2, 4, 4, 4};
        Integer [] arr2=new Integer[]{3, 4, 1, 5, 2};
        SinglyList <Integer> singlyList=new SinglyList(arr);
        SinglyList <Integer> singlyList1=new SinglyList(arr1);
        SinglyList <Integer> singlyList2=new SinglyList(singlyList1);
        SinglyList <Integer> singlyList3=new SinglyList(arr2);
        System.out.println(singlyList3.toString());
//        System.out.println("链表长度为:"+singlyList.size());
//        System.out.println(singlyList2.toString());
//        System.out.println("链表长度为:"+singlyList2.size());
//        System.out.println(singlyList.remove(3,4));
//        singlyList.insert(3,9);
//        System.out.println(singlyList.toString());
//        System.out.println("链表长度为:"+singlyList.size());
//        singlyList.remove(2);
//        System.out.println(singlyList.toString());
//        System.out.println("链表长度为:"+singlyList.size());
//        singlyList.remove(3);
//        System.out.println(singlyList.toString());
//        System.out.println("链表长度为:"+singlyList.size());
//        singlyList.removeKey(9);
//        System.out.println(singlyList.toString());
//        System.out.println("链表长度为:"+singlyList.size());
//        System.out.println(singlyList.get(0));
//        System.out.println(singlyList.searchKey(2));
//        System.out.println(singlyList.isEmpty());
//        singlyList.clear();
//        System.out.println(singlyList.isEmpty());
//        System.out.println("链表长度为:"+singlyList.size());
    }
}
