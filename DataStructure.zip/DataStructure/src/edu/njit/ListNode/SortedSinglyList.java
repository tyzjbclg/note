package edu.njit.ListNode;

public class SortedSinglyList <T extends Comparable<? super T>> extends SinglyList<T>{
    private boolean asc;
    public SortedSinglyList(SinglyList<T> list, boolean asc)
    {
        super(list);
        this.asc = asc;
        for(Node<T> first=this.head.next; first.next!=null; first=first.next)
        {
            Node<T> min=first;
            for(Node<T> p=min.next;   p!=null;   p=p.next)
                if(this.asc ? p.data.compareTo(min.data)<0 : p.data.compareTo(min.data)>0)
                    min = p;
            if(min!=first)
            {
                T temp = min.data;
                min.data = first.data;
                first.data = temp;
            }
        }
    }
    public static void main(String[] args) {
        Integer [] arr=new Integer[]{3, 4, 1, 5, 2};
        SinglyList <Integer> singlyList3=new SinglyList(arr);
        SortedSinglyList<Integer> sortedSinglyList=new SortedSinglyList<>(singlyList3,true);
        System.out.println(sortedSinglyList.toString());
    }
}
