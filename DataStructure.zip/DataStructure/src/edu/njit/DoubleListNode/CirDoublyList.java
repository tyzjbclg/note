package edu.njit.DoubleListNode;

public class CirDoublyList<T> {
    public DoubleNode<T> head;
    public CirDoublyList(){
        this.head=new DoubleNode<T>();
        this.head.prev=this.head;
        this.head.next=this.head;
    }

    public CirDoublyList(T [] values){
        this();
        DoubleNode<T> rear=this.head.next;
        for(int i=0;i<values.length;i++){
            if (values[i]!=null) {
                rear.next = new DoubleNode<T>(values[i], rear, null);
                rear=rear.next;
            }
        }
        rear.next=head;
        head.prev=rear;
    }
    public boolean isEmpty(){
        return this.head.next==this.head;
    }
    public T remove(int i){
        DoubleNode<T> front=this.head;
        for(int j=0;j<i&&front.next!=this.head;j++){
            front=front.next;
        }
        T x=front.next.data;
        front.next=front.next.next;
        front.next.prev=front;
        return x;
    }
    public void clear()

    {
        this.head.prev = this.head;
        this.head.next = this.head;
    }

    public int size()
    {
        int i = 0;
        for (DoubleNode<T> p = this.head.next; p != this.head; p = p.next)
            i++;
        return i;
    }
    public String toString(){
        String str=this.getClass().getName()+"(";
        for(DoubleNode<T> p=this.head.next;p!=this.head;p=p.next){
            str+=p.data.toString()+((p.next!=this.head)?",":"");
        }
        return str+")";
    }
    public void concat(CirDoublyList<T> list)
    {
        DoubleNode<T> rear= this.head.prev;
        rear.next = list.head.next;
        list.head.next.prev = rear;
        rear=list.head.prev;
        rear.next = this.head;
        this.head.prev = rear;
        list.clear();
    }
    public void deleteAll(CirDoublyList<T> pattern) {
        DoubleNode<T> rear=this.head.next;
        DoubleNode<T> front=this.head.next;
        DoubleNode<T> deleteFront,deleteRear,patternRear;
            while (rear != this.head) {
                patternRear=pattern.head.next;
                while (rear!=this.head &&patternRear!=pattern.head&& rear.equals(patternRear)) {
                    rear = rear.next;
                    patternRear = patternRear.next;
                }

                if(patternRear== pattern.head) {
                    deleteFront=front;
                    deleteRear=rear;
                    front=rear;
                    deleteFront.prev.next = deleteRear;
                    deleteRear.prev =deleteFront.prev;
                }
               else  {
                    front = front.next;
                    rear = front;
                }
            }
        }
    public static void main(String[] args) {
        Integer [] arr=new Integer[]{2,1,2,3,1,1,2,3};
//        Integer [] arr1=new Integer[]{1,2,3};
        Integer [] arr2=new Integer[]{1,2,3};
        Integer [] arr3=new Integer[]{1};
        Integer [] arr4=new Integer[]{2,1,2,null,3,1,1,2,3,7,7,8,1,2,9};
        Integer [] arr5=new Integer[]{1,2,null};
        CirDoublyList<Integer> cirDoublyList=new CirDoublyList<Integer>(arr);
        CirDoublyList<Integer> cirDoublyList2=new CirDoublyList<Integer>(arr2);
        CirDoublyList<Integer> cirDoublyList4=new CirDoublyList<Integer>(arr4);
        CirDoublyList<Integer> cirDoublyList5=new CirDoublyList<Integer>(arr5);
//        System.out.println(cirDoublyList.toString());
//        System.out.println("该循环双链表长度为:"+cirDoublyList.size());
//        Integer []arr1=new Integer[]{6,7,8};
//        CirDoublyList<Integer> cirDoublyList1=new CirDoublyList<Integer>(arr1);
//        cirDoublyList.concat(cirDoublyList1);
//        System.out.println(cirDoublyList.toString());
//        System.out.println(cirDoublyList1);
        System.out.println("删除子表之前"+cirDoublyList.toString());
        System.out.println("pattern表"+cirDoublyList2);
        cirDoublyList.deleteAll(cirDoublyList2);
        System.out.println("删除子表之后"+cirDoublyList.toString());
        System.out.println("删除子表之前"+cirDoublyList4.toString());
        System.out.println("pattern表"+ cirDoublyList5);
        cirDoublyList4.deleteAll(cirDoublyList5);
        System.out.println("删除子表之后"+cirDoublyList4.toString());
    }

}
