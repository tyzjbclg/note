package edu.njit.DoubleListNode;

public class DoubleNode<T> {
    public T data;
    public DoubleNode<T> prev,next;
    public DoubleNode(T data,DoubleNode<T> prev,DoubleNode<T> next){
        this.data=data;
        this.next=next;
        this.prev=prev;
    }
    public boolean equals(Object object)
    {
       if(this==object){
           return true;
       }
        if(object instanceof DoubleNode){
            DoubleNode node=(DoubleNode) object;
            return this.data.equals(node.data);
        }
        return false;
    }
    public DoubleNode(){
        this(null,null,null);
    }
    public String toString(){return this.data.toString();}
}
