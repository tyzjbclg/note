package edu.njit.DoubleListNode;

public class DoubleList<T>extends Object {
    public DoubleNode<T> head;
    public DoubleList(){
        this.head=new DoubleNode<T>();
    }
    public DoubleList(T[] values){
        this();
        DoubleNode<T> rear=this.head;
        for(int i=0;i<values.length;i++){
            if(values!=null){
                rear.data=values[i];
                rear=rear.next;
            }
        }
    }
    public boolean isEmpty(){
        return this.head.next==null;
    }
    public T get(int i){
        DoubleNode<T> p=this.head.next;
        for(int j=0;j<i&&p.next!=null;j++){
            p=p.next;
        }
        return p.data;
    }
    public void set(int i,T x){
        DoubleNode<T> p=this.head.next;
        for(int j=0;j<i&&p.next!=null;j++){
            p=p.next;
        }
        p.data=x;
    }
    public int size(){
        int count=0;
        for(DoubleNode<T>p=this.head;p.next!=null;p=p.next){
            count++;
        }
        return count;
    }
    public String toString(){
        String str=this.getClass().getName()+"(";  //返回类名
        for(DoubleNode<T> p = this.head.next; p!=null; p=p.next)
            str+=p.data.toString()+(p.next!=null?",":"");
        return str+")";
    }
}
