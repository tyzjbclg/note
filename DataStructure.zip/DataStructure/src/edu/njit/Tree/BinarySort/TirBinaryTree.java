package edu.njit.Tree.BinarySort;

import edu.njit.Tree.BinarySort.TriNode;

public class TirBinaryTree<T> {
    public TriNode<T> root;
    public TirBinaryTree(){
        this.root=null;
    }
    public TirBinaryTree(T[] inlist){
        this.root=create(inlist);
    }
    private int i=0;
    private TriNode<T> create(T [] inlist){
        TriNode<T> p=null;
        if(i<inlist.length){
            T elem=inlist[i++];
            if(elem!=null){
                p=new TriNode<T>(elem);
                p.left=create(inlist);
                p.right=create(inlist);
            }
        }
        return p;
    }
    public boolean isEmpty(){
        return this.root==null;
    }
    public void inorder(){
        System.out.println("(");
        TriNode<T> p=this.infixFirst(this.root);
        if (p!=null){
            System.out.println(p.data.toString());
            p=this.infixNext(p);
        }
        for(;p!=null;p=this.infixNext(p))
            System.out.println(","+p.data.toString());
        System.out.println(")");
    }
    public TriNode<T> infixFirst(TriNode<T> p){
        if(p!=null)
            while (p.left!=null)
                p=p.left;
            return p;
    }
    public TriNode<T> infixNext(TriNode<T> p){
        if(p!=null){
            if(p.right!=null)
                return this.infixFirst(p.right);
            while (p.parent!=null){
                if(p.parent.left==p)
                    return p.parent;
                p=p.parent;
            }
        }
        return null;
    }
}
