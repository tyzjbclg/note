package edu.njit.Tree.BinarySort;

public class TriNode<T> {
    public T data;
    public TriNode<T> parent,left,right;
    public TriNode(T data,TriNode parent,TriNode left,TriNode right){
        this.data=data;
        this.parent=parent;
        this.left=left;
        this.right=right;
    }
    public TriNode(T data){
        this.data=data;
    }
}
