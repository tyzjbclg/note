package edu.njit.Tree.Binary;

import edu.njit.LinearTable.SeqList;
import edu.njit.Stack.LinkedStack;
import edu.njit.Stack.Stack;

public class BinaryTrees {
    private static int i = 0;

    static BinaryNode binaryNode;
    public static <T extends Comparable<?super T>> boolean isSorted(BinaryTree<T> bitree)
    {
        binaryNode=null;
        return isSorted(bitree.root);
    }

    public static <T extends Comparable<?super T>> boolean isSorted(BinaryNode<T> p) {
        if (p!=null)
        {
            if (!isSorted(p.left))
                return false;

            if (binaryNode!=null&&p.data.compareTo((T)binaryNode.data)<0)
                return false;

            binaryNode=p;

            return isSorted(p.right);
        }
        return true;
    }

    public static <T>SeqList<T> diameter(BinaryTree<T> binaryTree){
        SeqList<T> seqList=new SeqList<T>();
        Stack<BinaryNode<T>> stack = new LinkedStack<BinaryNode<T>>();
        BinaryNode<T> p=binaryTree.root;
        while(p!=null || !stack.isEmpty()){
            if(p!=null)
            {
                if (!p.isLeaf())
                stack.push(p);
                p=p.left;
            }
            else
            {
                p=stack.pop();
                seqList.insert(p.data);
                p=p.right;
            }
        }
        return seqList;
    }
    public static BinaryTree<String> createByGenList(String genList) {
        BinaryTree<String> biTree = new BinaryTree<String>();
        i = 0;
        biTree.root = create(genList);
        return biTree;
    }
    private static BinaryNode<String> create(String genList) {
        BinaryNode<String> p = null;
        if (i < genList.length()) {
            char ch = genList.charAt(i);
            i++;
            if (ch == '^')
                return null;
            p = new BinaryNode<String>(ch + "");
            if (i < genList.length() && genList.charAt(i) == '(') {
                i++;
                p.left = create(genList);
                i++;
                p.right = create(genList);
                i++;
            }
        }
        return p;
    }


    public static void BCopy(BinaryTree<String> binaryTree,BinaryNode<String> node){
        binaryTree.root=copy(node);
    }
    private static BinaryNode<String> copy(BinaryNode<String> binaryNode){
        BinaryNode<String> p=null;
        if (binaryNode!=null) {
            p = new BinaryNode<String>(binaryNode.data);
            p.left = copy(binaryNode.left);
            p.right = copy(binaryNode.right);
        }
        return p;
    }
    public static BinaryTree<String> CreateByGenList(String genLists) {
        BinaryTree<String> binaryTree=new BinaryTree<>();
        LinkedStack<BinaryNode> stack=new LinkedStack<>();
        BinaryNode p = new BinaryNode<>(genLists.charAt(0));
        int flag = 0;
        binaryTree.root=p;
        for (int i=1;i < genLists.length();i++) {
            switch (genLists.charAt(i)) {
                case '(':
                    flag = 1;
                    stack.push(p);break;
                case ',':
                    flag = 2;break;
                case ')':
                    stack.pop();break;
                case '^': break;
                default:
                        if (flag==1){
                            p.left=new BinaryNode(genLists.charAt(i));
                            p=p.left;
                        }
                        else if (flag==2){
                            p=stack.peek();
                            p.right=new BinaryNode(genLists.charAt(i));
                            p=p.right;
                        }
            }
        }
        return binaryTree;
    }




    public static void main(String[] args) {
        String genList="A(B(D(^,G),^),C(E,F(H,^)))";
        String genList1="B(A,C)";
        String genList2="A(B(D(^,G),^),C(E,F(H,I)))";
        BinaryTree<String> binaryTree=BinaryTrees.createByGenList(genList);
        BinaryTree<String> binaryTree1=BinaryTrees.createByGenList(genList1);
        BinaryTree<String> binaryTree2=BinaryTrees.createByGenList(genList2);
        System.out.println(binaryTree.toGenListString1());
        System.out.println(binaryTree2.toGenListString());
        System.out.println(isSorted(binaryTree1));
        String str="abcdef";
        System.out.println(str.substring(1));
    }
}