package edu.njit.Tree.Binary;

import edu.njit.Stack.LinkedStack;
import edu.njit.Stack.Stack;

public class BinaryTree<T> {
    public BinaryNode<T> root;
    public BinaryTree(){
        this.root=null;
    }
    public boolean isEmpty(){
        return this.root==null;
    }
    public void insert(T x){
        if(x!=null)
            this.root=new BinaryNode<T>(x,this.root,null);
    }
    public BinaryNode<T> insert(BinaryNode<T> p, boolean left, T x){
        if(x==null||p==null)
            return null;
        if (left)
            return p.left=new BinaryNode<T>(x,p.left,null);
        return p.right=new BinaryNode<T>(x,null,p.right);
    }
    public void remove(BinaryNode<T> p,boolean left){
        if(p!=null){
            if (left)
                p.left=null;
            else
                p.right=null;
        }
    }
    public void clear(){
        this.root=null;
    }

    //先根次序遍历
    public void preorder(){
        preorder(this.root);
        System.out.println();
    }
    public void preorder(BinaryNode<T> p){
        if (p!=null){
            System.out.print(p.data.toString()+"");
            preorder(p.left);
            preorder(p.right);
        }
    }
    //中根次序遍历
    public void inorder(){
        inorder(this.root);
        System.out.println();
    }
    public void inorder(BinaryNode<T> p){
        if(p!=null){
            inorder(p.left);
            System.out.print(p.data.toString()+"");
            inorder(p.right);
        }
    }
    // 后根次序遍历
    public void postOrder(){
        postOrder(this.root);
        System.out.println();
    }
    public void postOrder(BinaryNode<T> p){
        if(p!=null){
            postOrder(p.left);
            postOrder(p.right);
            System.out.print(p.data.toString()+"");
        }
    }
    //构造二叉树
    public BinaryTree(T[] prelist){
        this.root=create(prelist);
    }
    private int i=0;
    private BinaryNode<T> create(T [] prelist){
        BinaryNode<T> p=null;
        if(i<prelist.length){
            T elem=prelist[i++];
            if(elem!=null){
                p=new BinaryNode<T>(elem);
                p.left=create(prelist);
                p.right=create(prelist);
            }
        }
        return p;
    }

    //拷贝构造二叉树
    public BinaryTree(BinaryTree<T> binaryTree){
        this.root=copy(binaryTree.root);
    }
    private BinaryNode<T> copy(BinaryNode<T> binaryNode){
        BinaryNode<T> p=null;
        if (binaryNode!=null) {
            p = new BinaryNode<T>(binaryNode.data);
            p.left = copy(binaryNode.left);
            p.right = copy(binaryNode.right);
        }
        return p;
    }

    public String toString()           //返回先根次序遍历二叉树所有结点的描述字符串，包含空子树标记
    {
        return "先根次序遍历二叉树："+toString(this.root);
    }
    public String toString(BinaryNode<T> p)     //返回先根次序遍历以p为根子树的描述字符串，递归方法
    {
        if(p==null)
            return "∧";                         //输出空子树标记
        return p.data.toString()+toString(p.left)+toString(p.right);
    }
    //用递归返回二叉树的广义表表示字符串
    public String toGenListString1(){
        return "递归算法二叉树的广义表表示: "+toGenListString1(this.root);
    }
    public String toGenListString1(BinaryNode<T> p){
        if(p==null)
            return "^";
        if(p.left==null&&p.right==null)
            return p.data.toString();
        return p.data.toString()+"("+toGenListString1(p.left)+","+toGenListString1(p.right)+")";
    }

    //用栈进行先根次序遍历
    public void preorderTraverse(){
        System.out.print("先根次序遍历二叉树（使用栈）:");
        Stack<BinaryNode<T>> stack=new LinkedStack<BinaryNode<T>>();
        BinaryNode<T> p=this.root;
        while(p!=null||!stack.isEmpty()){
            if(p!=null){
                System.out.print(p.data);
                stack.push(p);
                p=p.left;
            }
            else {
                System.out.print("^");
                  p=stack.pop();
                p=p.right;
            }
        }
        System.out.print("^");
        System.out.println();
    }
    //用栈进行中根次序遍历
    public void inorderTraverse()
    {
        System.out.print("中根次序遍历二叉树（使用栈）:");
        Stack<BinaryNode<T>> stack = new LinkedStack<BinaryNode<T>>();
        BinaryNode<T> p = this.root;
        while(p!=null || !stack.isEmpty()){
            if(p!=null)
            {
                stack.push(p);
                p=p.left;
            }
            else
            {
                System.out.print("∧");
                p=stack.pop();
                System.out.print(p.data);
                p=p.right;
            }
        }
        System.out.println("∧");
    }
    //用栈进行后根次序遍历
    public void postorderTraverse(){
        System.out.print("后根次序遍历二叉树（使用栈）:");
        LinkedStack<BinaryNode<T>> stack = new LinkedStack<BinaryNode<T>>();
        LinkedStack<BinaryNode<T>> output = new LinkedStack<BinaryNode<T>>();
        BinaryNode<T> p = this.root;
        System.out.print("^");
        while(p!=null||!stack.isEmpty()){
            if(p!=null){
                stack.push(p);
                output.push(p);
                p=p.right; //先进入右子树
            }else{
                output.push(new BinaryNode<T>(null));
                p = stack.pop();
                p = p.left;
            }
        }
        //依次出栈
        while(!output.isEmpty()){
            BinaryNode<T> node = output.pop();
            if(node.data==null)
                System.out.print("^");
            else
                System.out.print(node.data.toString());
        }
        System.out.println();
    }
    //用栈返回二叉树的广义表表示字符串(后根次序)
    public String toGenListString() {
        Stack<BinaryNode<T>> stack = new LinkedStack<BinaryNode<T>>();
        BinaryNode<T> p=this.root;
        BinaryNode<T> front = p;
        String str="";
        while (p != null || !stack.isEmpty()) {
            if (p != null) {
                str+=p.data.toString()+(!p.isLeaf()?"(":"");
                stack.push(p);
                p = p.left;
                if (p==null&&!stack.peek().isLeaf())
                    str+="^";
            } else {
                p = stack.peek();
                if (p.right == null || p.right == front) {
                    p=stack.pop();
                    if ((p.right==null)&&!p.isLeaf())
                        str+=",^)";
                    if ((p.isLeaf()&&stack.peek().right==p)||((p.left!=null&&p.right!=null)&&!p.right.isLeaf()))
                        str+=")";
                    front = p;
                    p = null;
                } else {
                    str+=",";
                    p=p.right;
                }
            }
        }
        return str;
    }
    //用栈返回二叉树的广义表表示字符串(先根次序)
    public void toPostorderGenListString() {
        System.out.print("先根遍历使用栈的二叉树广义表表示:");
        int i=0;
        String str=this.root.toString() ;
        Stack<BinaryNode<T>> stack = new LinkedStack<BinaryNode<T>>();
        BinaryNode<T> k = this.root;

        BinaryNode<T> p = k.left;
        stack.push(this.root);
        while(k!=null||!stack.isEmpty()){
            if (p==k.left){
                if(p!=null) {
                    str += "(" + p.data.toString();
                    if(p.left==null&&p.right==null){
                        k=stack.peek();
                        p=stack.pop().right;
                    }
                    else {
                        stack.push(p);
                        k = p;
                        p = p.left;
                    }
                }
                else {
                    str+="(^";
                    k=stack.peek();
                    p=stack.pop().right;
                }
            }
            else if(p==k.right){
                i++;
                if(p!=null) {
                    str += "," + p.data.toString();
                    if(p.left!=null||p.right!=null){
                        stack.push(p);
                    }
                }
                else{ str+=",^";}
                if(p==null||(p.left==null&&p.right==null)){
                    for(int j=0;j<i;j++) {
                        str += ")";
                    }
                    i=0;
                    k=stack.peek();
                    if (!stack.isEmpty()) {
                        p = stack.pop().right;
                    }
                }
                else {
                    k=p;
                    p=p.left;
                }
            }
        }
        System.out.println(str);
    }

    public static void main(String[] args) {
        String [] prelist={"A","B","D",null,"G",null,null,null,"C","E",null,null,"F","H"};
        BinaryTree<String> binaryTree=new BinaryTree<String>(prelist);
        BinaryTree<String> binaryTree1=new BinaryTree<String>(binaryTree);
        String genList1="A(B(D(^,G),^),C(E(J,K(M,N(P,^))),F(H,I)))";
        String genList2="A(B(D(^,G),^),C(E,F(H,^)))";
        BinaryTree<String> binaryTree5=BinaryTrees.createByGenList(genList1);
        BinaryTree<String> binaryTree6=BinaryTrees.CreateByGenList(genList1);
        binaryTree.preorder();
        binaryTree1.preorder();
        binaryTree.preorderTraverse();
        binaryTree.inorderTraverse();
        binaryTree.postorderTraverse();
        System.out.println( binaryTree.toGenListString1());
        System.out.println( binaryTree5.toGenListString1());
        binaryTree.toPostorderGenListString();
        System.out.println("后根遍历使用栈的二叉树广义表表示:"+binaryTree.toGenListString());
        System.out.println("后根遍历使用栈的二叉树广义表表示:"+binaryTree6.toGenListString());
        System.out.println("后根遍历使用栈的二叉树广义表表示:"+binaryTree5.toGenListString());
    }
}
