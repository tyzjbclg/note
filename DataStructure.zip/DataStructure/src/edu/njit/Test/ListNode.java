package edu.njit.Test;

public class ListNode {
    int value;
    ListNode nextnode;
    static int length=0;
    public ListNode(){}
    public ListNode(int n){
        this.value=n;
    }
    public static void add(ListNode addnode,ListNode head){
        ListNode nownode=head;
        for(int i=0;i<length;i++){
            nownode=nownode.nextnode;
        }
        nownode.nextnode=addnode;
        length++;
    }
    public static void insert(int nownum,ListNode head,ListNode insertnode){
        ListNode FirstNode=head;
        for(int i=0;i<nownum-1;i++){
            FirstNode=FirstNode.nextnode;
        }
        ListNode NextNode=FirstNode.nextnode;
        insertnode.nextnode=NextNode;
        FirstNode.nextnode=insertnode;
        length++;
    }
    public static void display(ListNode head){
        for(int i=0;i<length;i++){
            System.out.println(head.nextnode.value);
            head=head.nextnode;
        }
    }
    public static void main(String[] args) {
        ListNode head = new ListNode();
        add(new ListNode(1),head);
        add(new ListNode(2),head);
        add(new ListNode(3),head);
        add(new ListNode(4),head);
        display(head);
        ListNode node=new ListNode(8);
        insert(2,head,node);
        System.out.println("插入后的结果为:");
        display(head);
    }
}
