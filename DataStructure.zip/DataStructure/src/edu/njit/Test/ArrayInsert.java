package edu.njit.Test;

public class ArrayInsert {
    public static void main(String[] args) {
	int [] arr=new int[100];
	int count=0;
	for(int i=0;i<10;i++){
	    arr[i]=i;
	    count++;
    }
		System.out.println("插入前数组内内容为:");
	for(int b=0;b<count;b++){
        System.out.print(arr[b]+" ");
    }
		System.out.println();
	arr[2]=18;
	count++;
	for(int j=10;j>2;j--){
		arr[j]=arr[j-1];
	}
		System.out.println("插入后数组内容为:");
		for(int b=0;b<count;b++){
			System.out.print(arr[b]+" ");
		}
    }
}
