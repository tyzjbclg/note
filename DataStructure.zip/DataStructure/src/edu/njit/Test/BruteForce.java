package edu.njit.Test;

public class BruteForce {
    public static void main(String[] args) {
        String target="a,a,b,a,b,c,d,e";
        String pattern="a,b,c,d";
        for(int i=0;i<target.length();i++){
            if(target.charAt(i)==pattern.charAt(0)){
                
            }
        }
    }
}
