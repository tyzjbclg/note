package edu.njit.LinearTable;

public class SortedSeqList <T extends Comparable<? super T>> extends SeqList<T> {
}
