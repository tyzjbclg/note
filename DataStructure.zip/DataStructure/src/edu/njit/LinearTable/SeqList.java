package edu.njit.LinearTable;

public class SeqList<T> extends Object{
    protected int n;
    protected Object []element;
    public SeqList(int length){
            this.element=new Object[length];
            this.n=0;
        }
    public SeqList(){
        this(64);
    }
    public SeqList(T[] values){
        this(values.length*2);
        for(int i=0;i<values.length;i++){
            if(values[i]!=null)
                this.element[this.n++]=values[i];
        }
    }
    public boolean isEmpty(){
        return this.n==0;
    }
    public int size(){
        return this.n;
    }
    public T get(int i){
        if(i>=0&&i<this.n)
            return (T)this.element[i];
        return null;
    }
    public void set(int i,T x){
        if(x==null)
            throw new NullPointerException("x==null");
        if(i>=0&&i<this.n)
            this.element[i]=x;
        else
            throw new java.lang.IndexOutOfBoundsException(i+"");
    }
    public String toString(){
        String str=this.getClass().getName()+"(";
        if(this.n>0)
            str+=this.element[0].toString();
        for(int i=1;i<this.n;i++){
            str+=","+this.element[i].toString();
        }
        return str+")";
    }

    public void insert(T x) {
        this.element[this.n++]=x;
    }
    public T remove(int i){
        if(i>=0&&i<this.n){
            T x=(T)this.element[i];
            for(int j=i;j<this.n;j++){
                this.element[j]=this.element[j+1];
            }
            n--;
            return x;
        }
        return null;
    }

    public static void main(String[] args) {
        Integer [] arr=new Integer[]{1,2,3,4,5};
        SeqList<Integer> seqList=new SeqList<Integer>(arr);
        seqList.insert(7);
        seqList.remove(0);
        System.out.println(seqList.toString());
    }
}
