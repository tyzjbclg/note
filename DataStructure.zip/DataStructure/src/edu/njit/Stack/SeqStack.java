package edu.njit.Stack;

import edu.njit.LinearTable.SeqList;

public final class SeqStack<T>implements Stack<T> {
    private SeqList<T> list;
    public SeqStack(int length){
        this.list=new SeqList<T>(length);
    }
    public SeqStack(){
        this(64);
    }
    public boolean isEmpty(){
        return this.list.isEmpty();
    }
    public void push(T x){
        this.list.insert(x);
    }
    public T peek(){
        return this.list.get(list.size()-1);
    }
    public T pop(){
        return this.list.remove(list.size()-1);
    }
    public String toString(){
        String str="[";
        for (int i=0;i<this.list.size();i++){
            str+=this.list.get(i).toString()+(list.get(i+1)!=null?",":"");
        }
        return str+"]";
    }
    public String toPreviousString(){
        String str="[";
        for(int i=this.list.size()-1;i>=0;i--){
            str+=this.list.get(i).toString()+(list.get(i-1)!=null?",":"");
        }
        return str+"]";
    }
    public static void main(String[] args) {
        SeqStack<Integer>seqStack=new SeqStack<Integer>();
        seqStack.push(1);
        seqStack.push(2);
        seqStack.push(3);
        seqStack.push(4);
        seqStack.push(5);
        seqStack.pop();
        System.out.println(seqStack.toString());
        System.out.println(seqStack.toPreviousString());
    }
}
