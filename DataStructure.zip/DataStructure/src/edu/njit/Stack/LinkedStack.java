package edu.njit.Stack;

import edu.njit.ListNode.Node;
import edu.njit.ListNode.SinglyList;

public class LinkedStack<T> implements Stack<T>{
    private SinglyList<T> list;
    public LinkedStack(){
        this.list=new SinglyList<T>();
    }
    public boolean isEmpty(){
        return this.list.isEmpty();
    }
    public void push(T x){
        this.list.insert(x);
    }
    public T peek(){
        return this.list.get(this.list.size()-1);
    }
    public T pop(){
        if (this.list.isEmpty()==false) {
            T x = this.list.get(this.list.size() - 1);
            Node<T> rear = this.list.head;
            for (Node<T> p = this.list.head.next; p.next != null; p = p.next) {
                rear =rear.next;
            }
            rear.next=null;
            return x;
        }
        return null;
    }
    public String toString(){
        String str="[";
        for (Node<T>p=this.list.head.next;p!=null;p=p.next){
            str+=p.data+(p.next!=null?",":"");
        }
        return str+"]";
    }

    public static void main(String[] args) {
        LinkedStack<Integer> linkedStack=new LinkedStack<Integer>();
        linkedStack.push(1);
        linkedStack.push(2);
        linkedStack.push(3);
        linkedStack.push(4);
        linkedStack.push(5);
        linkedStack.pop();
        System.out.println(linkedStack.toString());
    }
}
